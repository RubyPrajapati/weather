const weatherApi={
    key: "9fd293664d5345f7e1acb55bc1bf5e0b",
    baseurl: "https://api.openweathermap.org/data/2.5/weather?"

}
const searchinputBox =document.getElementById("input-box");
//Event Listner Function on keypress
searchinputBox.addEventListener('keypress',(Event)=>{
    if(Event.keyCode==13){
        console.log(searchinputBox.value);
        getweatherReport(searchinputBox.value);
    }
    
});


//get weather report

function getweatherReport(city){
    fetch(`${weatherApi.baseurl}q=${city}&appid=${weatherApi.key}&units=metric`)
    .then(weather =>{
        return weather.json();
    }).then(showWeatherReport);
}
//show weather report
function showWeatherReport(weather){
    console.log(weather);

    let city=document.getElementById('city');
    city.innerText = `${weather.name}, ${weather.sys.country}`;

    let temperature=document.getElementById('temp');
    
    temperature.innerText =`${Math.round(weather.main.temp)}&deg;C`, `;`

    let minMaxTemp=document.getElementById('min-max');
    minMaxTemp.innerText=`${Math.floor(weather.main.temp-min)}&deg;C (min)/ ${Math.cell(weather.min.temp_max)}`;

    let weatherType=document.getElementById('weather');
    weatherType.innerText=`${weather.weather[0].main}`;

    let date=document.getElementById('date');
    let todayDate=new Date();
    date.innerText=dateManage(todayDate);

}
//date manage
function dateManage(dateArg){
    let days=['sunday','monday','tuesday','thrusday','friday','saturday'];

    let months=['jan','feb','Mar','Apr','May','June','Jul','Aug','Sep','Oct','Nov','Dec'];

    let year=dateArg.getfullYear();
    let month=months[dateArg.getMonth()];
    let date=dateArg.getDate();
    let day=days[dateArg.getDay()];

    return `${date} ${month} (${day}) ${year}`;
}


//https://api.openweathermap.org/data/2.5/weather?q={city name}&appid={API key}
